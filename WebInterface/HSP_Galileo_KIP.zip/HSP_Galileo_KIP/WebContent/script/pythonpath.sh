#!/bin/sh
cd $1
export PYTHONPATH=$1
python $2 $3 $4