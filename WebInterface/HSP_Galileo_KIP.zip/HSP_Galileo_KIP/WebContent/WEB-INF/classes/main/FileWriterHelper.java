package main;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.List;

public class FileWriterHelper {
	
	public static <T> void writeListToFile(String firstLine, List<T> list, URL url){
		
		try {
		    BufferedWriter out = new BufferedWriter(new FileWriter(url.getFile()));
		    out.write(firstLine);
		    for(T l : list){
		    	out.write(l.toString());
		    	out.newLine();
		    }
		    out.close();
		} catch (IOException e) {
		    // Handle exception
		}
		
	}

}
