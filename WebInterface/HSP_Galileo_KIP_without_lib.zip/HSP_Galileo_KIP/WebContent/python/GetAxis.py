import matplotlib.pyplot as plt


def get_axis():
    fig = plt.figure()
    ax = fig.add_subplot(111)
    return ax


def draw(filename):
    # plt.show()
    plt.savefig(filename)