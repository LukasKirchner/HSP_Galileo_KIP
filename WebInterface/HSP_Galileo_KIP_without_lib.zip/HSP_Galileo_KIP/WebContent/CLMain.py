import sys
import ValueGrid
from ConfigParser import RawConfigParser
import CLBasemap as Map
import GetAxis
import os

# check if called correctly
if len(sys.argv) == 4:
    conf =  sys.argv[1]
    csv =  sys.argv[2]
    out =  sys.argv[3]
else:
    print("got %i arguments" % len(sys.argv))
    print(sys.argv)
    sys.stderr.write("CLMain.py <configfile> <csvfile> <outputpath>\n")
    sys.exit(2)

    #conf = "C:\conf\conf.conf"
    #csv = "C:\csv\TestData.csv"
    #out = "C:\img"


__defaults = {
    "projection": "cyl",
    "lon": "0",
    "lat": "0",
    "resolution": "c",

    "time": "0",
    "sat": "all",

    "transparency": ".2",

    "minimap": "false",
}  

# clear output folder
for file in os.listdir(out):
    filepath = os.path.join(out, file)
    os.unlink(filepath)

config = RawConfigParser(__defaults)
config.read(conf)

grid = ValueGrid.load_from_csv(csv)

ax = GetAxis.get_axis()

# closure to automatically name each file
def __draw():
    class c:
        i = 0

    def draw():
        GetAxis.draw("%s/_%i.png" % (out, c.i))
        c.i += 1
    return draw

def __draw_legend():
    GetAxis.draw("%s/legend.png" % (out))
    return __draw_legend

# Map.draw_one(dict(config.items("DEFAULT")), grid, ax, __draw())
count = Map.draw_all(dict(config.items("DEFAULT")), grid, ax, __draw())

if config.get('DEFAULT','minimap') == "true":
	count = Map.draw_legend(dict(config.items("DEFAULT")), ax, __draw_legend())

# return the number of created images
# alternative: jsp:redirect stdout, write count to stdout
sys.exit(count)
