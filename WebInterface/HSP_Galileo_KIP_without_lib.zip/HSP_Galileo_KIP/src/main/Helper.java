package main;

public class Helper {

	public static String helpTextSetting(String setting){
		
		String helpText = "";
		
		switch (setting) {
		case "lon": helpText = "The longitude value of the center of the map. Maximum is +/- 180."; break;
		case "lat": helpText = "The latitude value of the center of the map. Maximum is +/- 90. Type in 0 to go to the equator."; break;
		case "zoom": helpText = "A float value between 0 and 0.9 to define the zoom in percentage. 0 is the whole world. e.g. 0.5"; break;
		case "sat": helpText = "The number of the satellite to show the values of. Type in all for all satellites so you get a picture for every satellite. Type in the satellite identifier to pick a satellite. Additionally it is possible to use avg for the average, min for the minimum, max for the maximum and sum for a sum over all satellites."; break;
		case "transparency": helpText = "Value between 0 and 0.5 to define the transparency of the colored areas."; break;
		case "ShowOriginMap": helpText = "Type in true or false to show or not show the origin map."; break;
		case "minimap": helpText = "Type in true or false to show or not show the minimap."; break;
		case "resolution": helpText = "Type in c here."; break;
		case "projection": helpText = "The projection type of the generated maps. Can be ortho or cyl. So you see the map in a flat or a cylindric view."; break;
		case "pdfExport": helpText = "Type in yes or no to define if you want a pdf export."; break;		
		case "cylindrical": helpText = "A true or false value, true means the map is cylindrical, false, it is orthogonal, in other words flat."; break;
		default: helpText = "An appropriate value for " + setting; break;
		}
		
		return helpText;		
	}
	
	public static String inputCorrectForSetting(String settingName, String value){
		
		String input = "";
		
		switch (settingName) {
		case "lon": input = "<input class=\"form-control\" type=\"text\" name=\"" + settingName + "\" min=\"-180\" max=\"180\" value=\"" + value + "\">";; break;
		case "lat": input = "<input class=\"form-control\" type=\"text\" name=\"" + settingName + "\" min=\"-90\" max=\"90\" value=\"" + value + "\">"; break;
		case "time": input = "<input class=\"form-control\" type=\"text\" name=\"" + settingName + "\" value=\"" + value + "\">";; break;
		case "sat": input = "<input class=\"form-control\" type=\"text\" name=\"" + settingName + "\" value=\"" + value + "\">";; break;		
		case "zoom": input = "<input class=\"form-control\" type=\"range\" name=\"" + settingName + "\" min=\"0.0\" max=\"0.9\" step=\"0.01\" value=\"" + value + "\">"; break;
		case "satellite": input = "<input class=\"form-control\" type=\"text\" name=\"" + settingName + "\" value=\"" + value + "\">"; break;
		case "transparency": input = "<input class=\"form-control\" type=\"range\" name=\"" + settingName + "\" min=\"0.0\" max=\"0.5\" step=\"0.01\" value=\"" + value + "\">"; break;
		case "ShowOriginMap": input = "<span class=\"form-control\">" + 
									"<span>" + 
										"<span>" + 
											"<span>" +
												"<input type=\"radio\" name=\"" + settingName + "\" value=\"true\" " + (value.equals("true")?"checked":"")  + ">" + 
											"</span>" +
											"<span class=\"radio-text\">" +
												" true " + 
											"</span>" +
										"</span>" + 
									"</span>" +
									"<span>" + 
										"<span>" + 
											"<span>" +
												"<input type=\"radio\" name=\"" + settingName + "\" value=\"false\" " + (value.equals("false")?"checked":"")  + ">" + 
											"</span>" +
											"<span class=\"radio-text\">" +
												" false " + 
											"</span>" +
										"</span>" +
									"</span>" + 
									"</span>";
		break;
		case "resolution": input = "<span class=\"form-control\">" + 
									"<span>" + 
										"<span>" + 
											"<span>" +
												"<input type=\"radio\" name=\"" + settingName + "\" value=\"c\" " + (value.equals("c")?"checked":"")  + ">" + 
											"</span>" +
											"<span class=\"radio-text\">" +
												" c " + 
											"</span>" +
										"</span>" + 
									"</span>" +
									"<span>" + 
										"<span>" + 
											"<span>" +
												"<input type=\"radio\" name=\"" + settingName + "\" value=\"c\" " + (value.equals("c")?"checked":"")  + ">" + 
											"</span>" +
											"<span class=\"radio-text\">" +
												" c " + 
											"</span>" +
										"</span>" +
									"</span>" + 
									"</span>";
		break;
		case "projection": input = "<span class=\"form-control\">" + 
				"<span>" + 
					"<span>" + 
						"<span>" +
							"<input type=\"radio\" name=\"" + settingName + "\" value=\"cyl\" " + (value.equals("cyl")?"checked":"")  + ">" + 
						"</span>" +
						"<span class=\"radio-text\">" +
							" cyl " + 
						"</span>" +
					"</span>" + 
				"</span>" +
				"<span>" + 
					"<span>" + 
						"<span>" +
							"<input type=\"radio\" name=\"" + settingName + "\" value=\"ortho\" " + (value.equals("ortho")?"checked":"")  + ">" + 
						"</span>" +
						"<span class=\"radio-text\">" +
							" ortho " + 
						"</span>" +
					"</span>" +
				"</span>" + 
				"</span>";
		break;
		case "pdfExport": input = "<span class=\"form-control\">" + 
				"<span>" + 
					"<span>" + 
						"<span>" +
							"<input type=\"radio\" name=\"" + settingName + "\" value=\"true\" " + (value.equals("true")?"checked":"")  + ">" + 
						"</span>" +
						"<span class=\"radio-text\">" +
							" true " + 
						"</span>" +
					"</span>" + 
				"</span>" +
				"<span>" + 
					"<span>" + 
						"<span>" +
							"<input type=\"radio\" name=\"" + settingName + "\" value=\"false\" " + (value.equals("false")?"checked":"")  + ">" + 
						"</span>" +
						"<span class=\"radio-text\">" +
							" false " + 
						"</span>" +
					"</span>" +
				"</span>" + 
				"</span>";
		break;
		case "cylindrical": input = "<span class=\"form-control\">" + 
				"<span>" + 
					"<span>" + 
						"<span>" +
							"<input type=\"radio\" name=\"" + settingName + "\" value=\"true\" " + (value.equals("true")?"checked":"")  + ">" + 
						"</span>" +
						"<span class=\"radio-text\">" +
							" true " + 
						"</span>" +
					"</span>" + 
				"</span>" +
				"<span>" + 
					"<span>" + 
						"<span>" +
							"<input type=\"radio\" name=\"" + settingName + "\" value=\"false\" " + (value.equals("false")?"checked":"")  + ">" + 
						"</span>" +
						"<span class=\"radio-text\">" +
							" false " + 
						"</span>" +
					"</span>" +
				"</span>" + 
				"</span>";
		break;
		case "minimap": input = "<span class=\"form-control\">" + 
				"<span>" + 
					"<span>" + 
						"<span>" +
							"<input type=\"radio\" name=\"" + settingName + "\" value=\"true\" " + (value.equals("true")?"checked":"")  + ">" + 
						"</span>" +
						"<span class=\"radio-text\">" +
							" true " + 
						"</span>" +
					"</span>" + 
				"</span>" +
				"<span>" + 
					"<span>" + 
						"<span>" +
							"<input type=\"radio\" name=\"" + settingName + "\" value=\"false\" " + (value.equals("false")?"checked":"")  + ">" + 
						"</span>" +
						"<span class=\"radio-text\">" +
							" false " + 
						"</span>" +
					"</span>" +
				"</span>" + 
				"</span>";
		break;
		default: input = "<input class=\"form-control\" type=\"text\" name=\"" + settingName + "\" value=\"" + value + "\">"; break;
		}
		
		return input;
		
	}
	
}
